package login.queue;

import login.domain.LoginResult;

/**
 * Created by fdse-jichao on 2017/8/11.
 */
public class GlobalValue {

    public static LoginResult lr;

}
