package cancel.queue;

import cancel.domain.ChangeOrderResult;

public class GlobalValue {

    public static ChangeOrderResult changeOrderResult;

}
