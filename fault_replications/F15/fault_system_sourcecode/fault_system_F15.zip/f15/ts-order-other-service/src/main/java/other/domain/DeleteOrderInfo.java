package other.domain;

public class DeleteOrderInfo {

    public String orderId;

    public DeleteOrderInfo() {
        //Default Constructor
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
