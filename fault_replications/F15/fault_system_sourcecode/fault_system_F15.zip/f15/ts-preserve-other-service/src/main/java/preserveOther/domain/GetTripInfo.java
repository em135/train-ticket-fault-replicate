package preserveOther.domain;

public class GetTripInfo {

    private String tripId;

    public GetTripInfo() {
        //Default Constructor
    }

    public String getTripId() {
        return tripId;
    }

    public void setTripId(String tripId) {
        this.tripId = tripId;
    }
}
